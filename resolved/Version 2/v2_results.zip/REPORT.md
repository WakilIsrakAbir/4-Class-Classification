# Version 2 (4-class) results report

> Final run: all folds and models finished.

Generated 2026-11-09 14:30 · preset `fast` · 3 test folds · 8189 images evaluated out-of-fold · models: ResNet50, ConvNeXt-T (IN-1k), DINOv2 ViT-B/14, DINOv3 ViT-B/16

## Headline numbers

- **Stacking (proposed)**: accuracy **85.20 ± 1.13%**, macro-F1 **87.68 ± 0.88%**, macro-AUC 0.9641 ± 0.0033, Cohen's kappa 0.786 (mean ± SD over test folds).
- Best single model, **ConvNeXt-T (IN-1k)**: accuracy 84.56%, macro-F1 86.99% (pooled). Proposed minus best single, macro-F1: +0.69 [+0.22, +1.17] points; McNemar p (Holm) = 0.041.
- Uncertainty-based referral: accuracy **86.99%** at 95% coverage, **88.62%** at 90% and **91.12%** at 80% (the remaining least-confident images go to an ophthalmologist).
- Referable disease (any disease vs. normal): sensitivity 85.19%, specificity 89.37%, AUC 0.9328.
- Normal→Glaucoma errors: 103 (proposed) vs. 95 (best single).
- Duplicate audit: 1193 of 10449 images are in near-duplicate clusters; a naive image-level 70/15/15 split would have put a duplicate of 6.7% of its test images into training.
- Data quality: 8779 task images; removed before splitting: 206 label conflicts (176 clusters, incl. copies filed as AMD/hypertensive/myopia), 0 non-fundus, 19 ungradable, 365 duplicate copies; 8189 images used.
- Harmonisation check at 256 px: original vs. '512 x 512 + JPEG' copy of the same image told apart with 53.3% accuracy (50% = no processing trace).
- Patients: 3154 ODIR patients (2405 with both eyes) are kept in one fold; a naive image-level split would have put the other eye or a duplicate of 39.6% of its test images into training.
- Shortcut baseline (no retina pixels, acquisition metadata only): macro-F1 67.93% vs. 87.67% for Stacking (proposed).
- Within ODIR only (one camera source): ConvNeXt-T: Macro-F1 (%) 73.18%, Soft vote: top-2: Macro-F1 (%) 73.38%, Stacking: Macro-F1 (%) 73.96%
- Source-shift test (ResNet50, ODIR disease images never seen in training): accuracy 40.33%, macro-F1 39.85% (same images in CV: 67.97% / 70.55%).

## Data quality (tab_data_quality.tex)

| Class | Images | In duplicate clusters | Label conflicts | Not fundus | Ungradable | Duplicate copies | Excluded | Used | Unique eyes |
|---|---|---|---|---|---|---|---|---|---|
| Cataract | 1008 | 398 | 13 | 0 | 7 | 224 | 244 | 764 | 764 |
| DR | 3128 | 149 | 27 | 0 | 0 | 63 | 90 | 3038 | 3038 |
| Glaucoma | 1646 | 303 | 165 | 0 | 4 | 72 | 241 | 1405 | 1405 |
| Normal | 2997 | 9 | 1 | 0 | 8 | 6 | 15 | 2982 | 2982 |
| Total | 8779 | 859 | 206 | 0 | 19 | 365 | 590 | 8189 | 8189 |

## Sources (tab_sources.tex)

| Source | Cataract | DR | Glaucoma | Normal | Total |
|---|---|---|---|---|---|
| ODIR | 276 | 1604 | 289 | 2982 | 5151 |
| CataractPNG | 85 | 0 | 0 | 0 | 85 |
| EyeDiseaseKaggle | 403 | 0 | 0 | 0 | 403 |
| Mendeley | 0 | 1434 | 1116 | 0 | 2550 |
| Total | 764 | 3038 | 1405 | 2982 | 8189 |

## Class viability (class_viability.csv)

| Class | Unique eyes | Sources | In shared sources (%) | ODIR-camera probe F1 | OK |
|---|---|---|---|---|---|
| Cataract | 764 | CataractPNG, EyeDiseaseKaggle, ODIR | 36.1 | 0.876 | True |
| DR | 3038 | Mendeley, ODIR | 100.0 | 0.552 | True |
| Glaucoma | 1405 | Mendeley, ODIR | 100.0 | 0.326 | True |
| Normal | 2982 | ODIR | 100.0 | 0.637 | True |

## Shortcut baselines (tab_shortcut.tex)

| Predictor | Uses retina pixels | Accuracy (%) | Bal. Acc. (%) | Macro-F1 (%) |
|---|---|---|---|---|
| Majority class | no | 37.10 | 25.00 | 13.53 |
| Source dataset -> its most frequent class | no | 59.89 | 52.77 | 50.65 |
| Acquisition metadata only (size, file, format, FOV) | no | 62.35 | 67.71 | 67.93 |
| Stacking (proposed) | yes | 85.20 | 87.86 | 87.67 |

## Within-source performance (tab_per_source.tex)

| Source | Images | Classes | ConvNeXt-T: Acc. (%) | ConvNeXt-T: Macro-F1 (%) | Soft vote: top-2: Acc. (%) | Soft vote: top-2: Macro-F1 (%) | Stacking: Acc. (%) | Stacking: Macro-F1 (%) |
|---|---|---|---|---|---|---|---|---|
| ODIR | 5151 | C D G N | 77.32 | 73.18 | 77.60 | 73.38 | 78.08 | 73.96 |
| CataractPNG | 85 | C | 95.29 |  | 97.65 |  | 92.94 |  |
| EyeDiseaseKaggle | 403 | C | 99.50 |  | 99.75 |  | 99.75 |  |
| Mendeley | 2550 | D G | 96.47 | 96.88 | 96.94 | 97.34 | 97.02 | 97.22 |

## Source-shift test (tab_source_shift.tex)

| Class | Test images | Recall, CV (%) | Recall, source-shift (%) | Called normal, CV (%) | Called normal, source-shift (%) |
|---|---|---|---|---|---|
| Cataract | 276 | 96.7 | 96.0 | 1.8 | 3.3 |
| DR | 1604 | 55.8 | 6.8 | 42.5 | 92.5 |
| Glaucoma | 289 | 45.0 | 1.0 | 44.6 | 96.2 |
| Normal | 844 | 89.6 | 99.3 |  |  |

## Source-shift test, all models (tab_source_shift_models.tex)

| Model | Test images | Macro-F1, CV (%) | Macro-F1, source-shift (%) | Bal. acc., source-shift (%) | Disease called normal, CV (%) | Disease called normal, source-shift (%) |
|---|---|---|---|---|---|---|
| ResNet50 | 3013 | 70.6 | 39.8 | 50.8 | 37.6 | 81.6 |
| DINOv3 ViT-B/16 | 3013 | 65.8 | 40.6 | 50.7 | 42.6 | 80.6 |

## Main results (Table: tab_main_results.tex)

| Model | Accuracy (%) | Bal. Acc. (%) | Macro-P (%) | Macro-R (%) | Macro-F1 (%) | Kappa | Macro-AUC | ECE (%) |
|---|---|---|---|---|---|---|---|---|
| ResNet50 | 83.97 ± 0.97 | 86.83 ± 0.67 | 86.66 ± 1.12 | 86.83 ± 0.67 | 86.40 ± 0.99 | 0.769 ± 0.014 | 0.958 ± 0.003 | 2.32 |
| ConvNeXt-T (IN-1k) | 84.57 ± 0.53 | 87.39 ± 0.50 | 87.20 ± 0.69 | 87.39 ± 0.50 | 86.99 ± 0.64 | 0.777 ± 0.008 | 0.962 ± 0.001 | 2.31 |
| DINOv2 ViT-B/14 | 84.64 ± 1.27 | 87.20 ± 1.02 | 87.29 ± 1.56 | 87.20 ± 1.02 | 86.91 ± 1.13 | 0.778 ± 0.018 | 0.961 ± 0.003 | 2.66 |
| DINOv3 ViT-B/16 | 82.24 ± 0.37 | 84.35 ± 0.80 | 85.23 ± 0.60 | 84.35 ± 0.80 | 84.26 ± 0.06 | 0.743 ± 0.006 | 0.953 ± 0.002 | 2.43 |
| Best single (val-selected) | 84.53 ± 0.52 | 87.39 ± 0.50 | 86.80 ± 0.96 | 87.39 ± 0.50 | 86.76 ± 0.68 | 0.777 ± 0.008 | 0.962 ± 0.001 | 2.28 |
| Soft vote: top-2 (submitted strategy) | 84.92 ± 0.71 | 87.78 ± 0.69 | 87.70 ± 0.40 | 87.78 ± 0.69 | 87.39 ± 0.57 | 0.782 ± 0.011 | 0.964 ± 0.003 | 2.15 |
| Soft vote: all global | 85.04 ± 0.91 | 87.60 ± 0.65 | 87.98 ± 0.92 | 87.60 ± 0.65 | 87.34 ± 0.80 | 0.784 ± 0.013 | 0.964 ± 0.002 | 1.89 |
| Stacking (proposed) | 85.20 ± 1.13 | 87.86 ± 0.78 | 88.01 ± 0.98 | 87.86 ± 0.78 | 87.68 ± 0.88 | 0.786 ± 0.016 | 0.964 ± 0.003 | 1.44 |

## Statistics (tab_statistics.tex)

| Model | Acc. [95% CI] | Macro-F1 [95% CI] | Macro-AUC [95% CI] | ΔF1 vs proposed [95% CI] | McNemar b/c | p_mcnemar | p_corr_t | p_mcnemar (Holm) |
|---|---|---|---|---|---|---|---|---|
| ResNet50 | 83.97 [83.03, 84.80] | 86.40 [85.56, 87.18] | 0.9582 [0.9547, 0.9615] | +1.28 [+0.79, +1.77] | 282/181 | <0.001 | 0.011 | <0.001 |
| ConvNeXt-T (IN-1k) | 84.56 [83.67, 85.37] | 86.99 [86.20, 87.70] | 0.9618 [0.9587, 0.9648] | +0.69 [+0.22, +1.17] | 219/167 | 0.009 | 0.129 | 0.041 |
| DINOv2 ViT-B/14 | 84.64 [83.78, 85.51] | 86.89 [86.08, 87.69] | 0.9610 [0.9577, 0.9641] | +0.78 [+0.25, +1.31] | 244/198 | 0.032 | 0.420 | 0.097 |
| DINOv3 ViT-B/16 | 82.24 [81.28, 83.14] | 84.26 [83.37, 85.08] | 0.9527 [0.9493, 0.9562] | +3.42 [+2.81, +4.08] | 438/196 | <0.001 | 0.061 | <0.001 |
| Best single (val-selected) | 84.53 [83.63, 85.32] | 86.75 [85.94, 87.50] | 0.9617 [0.9586, 0.9646] | +0.93 [+0.45, +1.43] | 237/182 | 0.008 | 0.279 | 0.041 |
| Soft vote: top-2 (submitted strategy) | 84.92 [84.05, 85.76] | 87.39 [86.63, 88.12] | 0.9636 [0.9605, 0.9667] | +0.29 [-0.10, +0.67] | 145/122 | 0.178 | 0.435 | 0.356 |
| Soft vote: all global | 85.04 [84.13, 85.88] | 87.33 [86.52, 88.11] | 0.9642 [0.9613, 0.9671] | +0.34 [-0.01, +0.74] | 119/106 | 0.424 | 0.437 | 0.424 |
| Stacking (proposed) | 85.20 [84.32, 86.04] | 87.67 [86.87, 88.41] | 0.9639 [0.9608, 0.9670] |  |  |  |  |  |

## Per-class performance of the proposed model (tab_per_class.tex)

| Class | Sensitivity (%) | Specificity (%) | F1 (%) | AUC | Support |
|---|---|---|---|---|---|
| Cataract | 98.04 | 99.52 | 96.71 | 0.9995 | 764 |
| DR | 77.06 | 95.24 | 83.25 | 0.9423 | 3038 |
| Glaucoma | 86.98 | 97.64 | 87.69 | 0.9812 | 1405 |
| Normal | 89.37 | 85.19 | 83.05 | 0.9328 | 2982 |

## Normal vs. glaucoma and referable disease (tab_normal_glaucoma.tex)

| Model | Normal→Glaucoma | Glaucoma→Normal | Glaucoma sens. (%) | Referable sens. (%) | Referable spec. (%) | Referable AUC |
|---|---|---|---|---|---|---|
| ResNet50 | 92 | 131 | 86.33 | 84.12 | 89.20 | 0.9244 |
| ConvNeXt-T (IN-1k) | 95 | 123 | 86.26 | 84.77 | 89.13 | 0.9300 |
| DINOv2 ViT-B/14 | 76 | 144 | 85.77 | 84.41 | 89.77 | 0.9268 |
| DINOv3 ViT-B/16 | 84 | 160 | 83.13 | 81.56 | 89.84 | 0.9151 |
| Best single (val-selected) | 101 | 125 | 86.12 | 84.90 | 89.20 | 0.9301 |
| Soft vote: top-2 (submitted strategy) | 92 | 130 | 86.69 | 84.44 | 90.01 | 0.9319 |
| Soft vote: all global | 74 | 143 | 85.77 | 83.68 | 91.95 | 0.9326 |
| Stacking (proposed) | 103 | 127 | 86.98 | 85.19 | 89.37 | 0.9328 |

## Referral (tab_referral.tex)

| Model | Acc@100% cov. | Acc@95% cov. | Acc@90% cov. | Acc@80% cov. | AURC (x100) |
|---|---|---|---|---|---|
| Stacking (proposed) | 85.20 | 86.99 | 88.62 | 91.12 | 4.38 |
| ConvNeXt-T (IN-1k) | 84.56 | 86.41 | 88.09 | 90.63 | 4.88 |
| Soft vote: top-2 (submitted strategy) | 84.92 | 86.68 | 88.43 | 90.84 | 4.55 |

## Explainability metrics (tab_xai.tex)

| Model | Method | Deletion AUC ↓ | Insertion AUC ↑ | Avg. Drop (%) ↓ | Increase (%) ↑ | Disc enrichment (glaucoma) ↑ | Pointing game (glaucoma, %) ↑ |
|---|---|---|---|---|---|---|---|
| Ensemble of 2 CNNs | Grad-CAM | 0.407 | 0.703 | 21.75 | 23.00 | 4.69 | 82.0 |
| Ensemble of 2 CNNs | Grad-CAM++ | 0.418 | 0.697 | 20.24 | 26.00 | 4.30 | 82.0 |
| Ensemble of 2 CNNs | LayerCAM | 0.420 | 0.694 | 20.86 | 24.50 | 4.14 | 82.0 |
| Ensemble of 2 CNNs | Random | 0.397 | 0.412 | 71.83 | 17.00 | 1.00 | 8.0 |
| ConvNeXt-T (IN-1k) | Grad-CAM | 0.451 | 0.739 | 25.70 | 21.50 | 5.75 | 86.0 |
| ConvNeXt-T (IN-1k) | Grad-CAM++ | 0.446 | 0.744 | 24.54 | 27.00 | 4.74 | 86.0 |
| ConvNeXt-T (IN-1k) | LayerCAM | 0.446 | 0.744 | 25.10 | 26.00 | 4.68 | 86.0 |
| ConvNeXt-T (IN-1k) | Random | 0.422 | 0.459 | 69.77 | 12.00 | 1.00 | 14.0 |

## Model complexity (tab_complexity.tex)

| Model | Input | Params (M) | GFLOPs | Latency (ms) |
|---|---|---|---|---|
| ResNet50 | 256x256 | 23.52 | 10.68 | 6.8 |
| ConvNeXt-T (IN-1k) | 224x224 | 27.82 | 8.91 | 7.07 |
| DINOv2 ViT-B/14 | 224x224 | 85.73 | 46.32 | 6.85 |
| DINOv3 ViT-B/16 | 224x224 | 85.64 | 35.86 | 11.71 |

## Ensemble members chosen on validation data, per fold

| fold | best_single | top2 |
|---|---|---|
| 0 | DINOv2 ViT-B/14 | DINOv2 ViT-B/14 + ConvNeXt-T (IN-1k) |
| 1 | ConvNeXt-T (IN-1k) | ConvNeXt-T (IN-1k) + ResNet50 |
| 2 | ConvNeXt-T (IN-1k) | ConvNeXt-T (IN-1k) + DINOv2 ViT-B/14 |

## Duplicate audit

```json
{
  "n_images": 10449,
  "n_unreadable": 0,
  "classes": [
    "C",
    "D",
    "G",
    "N"
  ],
  "exact_duplicate_pairs": 172,
  "phash_pairs": 467,
  "deep_pairs": 645,
  "hash_threshold_used_bits_of_256": 25,
  "cosine_threshold_used": 0.97,
  "n_clusters": 9789,
  "n_images_in_clusters_gt1": 1193,
  "largest_cluster": 6,
  "odir_patients": 3154,
  "odir_patients_with_both_eyes": 2405,
  "n_cv_groups": 7386,
  "official_eval_with_dup_in_train": null,
  "naive_70_15_15_test_with_dup_in_train": 0.06681852695520121,
  "naive_70_15_15_test_with_same_patient_in_train": 0.3325740318906606,
  "naive_70_15_15_test_with_dup_or_patient_in_train": 0.39635535307517084,
  "nn_cos_quantiles": {
    "0.5": 0.9363691806793213,
    "0.9": 0.9704038500785828,
    "0.99": 0.9999998807907104
  },
  "label_conflict_clusters": 176,
  "label_conflict_images": 206,
  "label_conflict_classes": {
    "Glaucoma + Myopia": 145,
    "DR + Glaucoma": 8,
    "AMD + DR": 7,
    "DR + Myopia": 6,
    "Cataract + DR": 4,
    "Cataract + Hypertensive": 3,
    "AMD + Glaucoma": 1,
    "DR + Hypertensive": 1,
    "Glaucoma + Normal": 1
  },
  "same_odir_eye_in_two_classes": 7,
  "non_fundus_images": 0,
  "excluded_label_conflict": 206,
  "excluded_non_fundus": 0,
  "excluded_ungradable": 19,
  "excluded_duplicate_copies": 365,
  "not_in_task_images": 1670,
  "task_images_before_cleaning": 8779,
  "n_used": 8189,
  "imbalance_ratio_used": 3.9764397905759163,
  "chain_probe_acc": 0.5333333333333333,
  "chain_probe_img_size": 256
}
```

## Figures

### fig_benchmark

![fig_benchmark](figures/fig_benchmark.png)

### fig_calibration_referral

![fig_calibration_referral](figures/fig_calibration_referral.png)

### fig_complexity

![fig_complexity](figures/fig_complexity.png)

### fig_confusion

![fig_confusion](figures/fig_confusion.png)

### fig_data_quality

![fig_data_quality](figures/fig_data_quality.png)

### fig_duplicate_audit

![fig_duplicate_audit](figures/fig_duplicate_audit.png)

### fig_gradcam

![fig_gradcam](figures/fig_gradcam.png)

### fig_learning_curves

![fig_learning_curves](figures/fig_learning_curves.png)

### fig_preprocessing

![fig_preprocessing](figures/fig_preprocessing.png)

### fig_removed_ungradable

![fig_removed_ungradable](figures/fig_removed_ungradable.png)

### fig_roc

![fig_roc](figures/fig_roc.png)

### fig_source_shift

![fig_source_shift](figures/fig_source_shift.png)

### fig_source_shift_models

![fig_source_shift_models](figures/fig_source_shift_models.png)

### fig_sources

![fig_sources](figures/fig_sources.png)

### fig_xai_faithfulness

![fig_xai_faithfulness](figures/fig_xai_faithfulness.png)
