# Eye-7 results report

> **INTERIM RESULTS: not all folds/models finished. Do not report these numbers.**

Generated 2026-11-06 16:02 · preset `3h` · 1 test folds · 3224 images evaluated out-of-fold · models: ResNet50, MobileNetV4-M, ConvNeXt-T (IN-1k), ConvNeXt-T (DINOv3), DINOv2 ViT-B/14, ConvNeXt-S (IN-22k) [disc]

## Headline numbers

- **DA-MVE (proposed)**: accuracy **86.35 ± 0.00%**, macro-F1 **89.03 ± 0.00%**, macro-AUC 0.9776 ± 0.0000, Cohen's kappa 0.821 (mean ± SD over test folds).
- Best single model, **ConvNeXt-T (IN-1k)**: accuracy 85.73%, macro-F1 88.03% (pooled). Proposed minus best single, macro-F1: +1.01 [+0.14, +1.93] points; McNemar p (Holm) = 0.452.
- Uncertainty-based referral: accuracy **87.85%** at 95% coverage, **89.35%** at 90% and **92.44%** at 80% (the remaining least-confident images go to an ophthalmologist).
- Referable disease (any disease vs. normal): sensitivity 88.82%, specificity 88.96%, AUC 0.9488.
- Normal→Glaucoma errors: 33 (proposed) vs. 41 (best single).
- Duplicate audit: 1056 of 10029 images are in near-duplicate clusters; a naive image-level 70/15/15 split would have put a duplicate of 8.6% of its test images into training.
- Data quality: 365 images (172 clusters) have a near-identical copy filed under another class; 0 images are not fundus photographs. Excluded before splitting: 365 + 0; 9664 images used.
- Harmonisation check at 256 px: original vs. '512 x 512 + JPEG' copy of the same image told apart with 53.3% accuracy (50% = no processing trace).
- Patients: 3098 ODIR patients (2336 with both eyes) are kept in one fold; a naive image-level split would have put the other eye or a duplicate of 40.4% of its test images into training.
- Shortcut baseline (no retina pixels, acquisition metadata only): macro-F1 62.77% vs. 89.03% for DA-MVE (proposed).
- Within ODIR only (one camera source): ConvNeXt-T: Macro-F1 (%) 79.73%, Soft vote: top-2: Macro-F1 (%) 80.32%, DA-MVE: Macro-F1 (%) 80.81%
- Source-shift test: not run.

## Data quality (tab_data_quality.tex)

| Class | Images | In duplicate clusters | Label conflicts | Not fundus | Excluded | Used | Unique eyes |
|---|---|---|---|---|---|---|---|
| AMD | 511 | 10 | 8 | 0 | 8 | 503 | 502 |
| Cataract | 1008 | 396 | 7 | 0 | 7 | 1001 | 771 |
| DR | 3128 | 148 | 26 | 0 | 26 | 3102 | 3039 |
| Glaucoma | 1646 | 303 | 165 | 0 | 165 | 1481 | 1409 |
| Myopia | 739 | 190 | 158 | 0 | 158 | 581 | 565 |
| Normal | 2997 | 9 | 1 | 0 | 1 | 2996 | 2993 |
| Total | 10029 | 1056 | 365 | 0 | 365 | 9664 | 9279 |

## Sources (tab_sources.tex)

| Source | AMD | Cataract | DR | Glaucoma | Myopia | Normal | Total |
|---|---|---|---|---|---|---|---|
| ODIR | 0 | 282 | 1608 | 294 | 239 | 2996 | 5419 |
| ARMD (RFMiD/JSIEC/ARIA) | 231 | 0 | 0 | 0 | 0 | 0 | 231 |
| CataractPNG | 0 | 100 | 0 | 0 | 0 | 0 | 100 |
| EyeDiseaseKaggle | 0 | 619 | 0 | 0 | 0 | 0 | 619 |
| Mendeley | 0 | 0 | 1494 | 1187 | 342 | 0 | 3023 |
| ODIR-copy (ARMD set) | 272 | 0 | 0 | 0 | 0 | 0 | 272 |
| Total | 503 | 1001 | 3102 | 1481 | 581 | 2996 | 9664 |

## Class viability (class_viability.csv)

| Class | Unique eyes | Sources | In shared sources (%) | ODIR-camera probe F1 | OK |
|---|---|---|---|---|---|
| AMD | 502 | ARMD (RFMiD/JSIEC/ARIA), ODIR-copy (ARMD set) | 54.1 | 0.621 | True |
| Cataract | 771 | CataractPNG, EyeDiseaseKaggle, ODIR | 28.2 | 0.85 | True |
| DR | 3039 | Mendeley, ODIR | 100.0 | 0.537 | True |
| Glaucoma | 1409 | Mendeley, ODIR | 100.0 | 0.347 | True |
| Myopia | 565 | Mendeley, ODIR | 100.0 | 0.78 | True |
| Normal | 2993 | ODIR | 100.0 | 0.614 | True |

## Shortcut baselines (tab_shortcut.tex)

| Predictor | Uses retina pixels | Accuracy (%) | Bal. Acc. (%) | Macro-F1 (%) |
|---|---|---|---|---|
| Majority class | no | 32.20 | 16.67 | 8.12 |
| Source dataset -> its most frequent class | no | 59.03 | 53.61 | 50.76 |
| Acquisition metadata only (size, file, format, FOV) | no | 60.95 | 62.52 | 62.77 |
| DA-MVE (proposed) | yes | 86.35 | 89.24 | 89.03 |

## Within-source performance (tab_per_source.tex)

| Source | Images | Classes | ConvNeXt-T: Acc. (%) | ConvNeXt-T: Macro-F1 (%) | Soft vote: top-2: Acc. (%) | Soft vote: top-2: Macro-F1 (%) | DA-MVE: Acc. (%) | DA-MVE: Macro-F1 (%) |
|---|---|---|---|---|---|---|---|---|
| ODIR | 1898 | A C D G M N | 79.45 | 79.73 | 80.19 | 80.32 | 80.03 | 80.81 |
| ARMD (RFMiD/JSIEC/ARIA) | 81 | A | 98.77 |  | 98.77 |  | 98.77 |  |
| CataractPNG | 34 | C | 88.24 |  | 91.18 |  | 91.18 |  |
| EyeDiseaseKaggle | 206 | C | 99.51 |  | 100.00 |  | 100.00 |  |
| Mendeley | 1005 | D G M | 93.63 | 90.31 | 94.23 | 91.51 | 94.33 | 91.39 |

## Main results (Table: tab_main_results.tex)

| Model | Accuracy (%) | Bal. Acc. (%) | Macro-P (%) | Macro-R (%) | Macro-F1 (%) | Kappa | Macro-AUC | ECE (%) |
|---|---|---|---|---|---|---|---|---|
| ResNet50 | 83.62 ± 0.00 | 87.05 ± 0.00 | 85.88 ± 0.00 | 87.05 ± 0.00 | 86.09 ± 0.00 | 0.785 ± 0.000 | 0.973 ± 0.000 | 2.49 |
| MobileNetV4-M | 75.25 ± 0.00 | 77.75 ± 0.00 | 75.70 ± 0.00 | 77.75 ± 0.00 | 75.73 ± 0.00 | 0.678 ± 0.000 | 0.936 ± 0.000 | 5.40 |
| ConvNeXt-T (IN-1k) | 85.73 ± 0.00 | 88.51 ± 0.00 | 87.84 ± 0.00 | 88.51 ± 0.00 | 88.03 ± 0.00 | 0.813 ± 0.000 | 0.976 ± 0.000 | 2.35 |
| ConvNeXt-T (DINOv3) | 82.07 ± 0.00 | 85.28 ± 0.00 | 84.59 ± 0.00 | 85.28 ± 0.00 | 84.49 ± 0.00 | 0.765 ± 0.000 | 0.968 ± 0.000 | 2.63 |
| DINOv2 ViT-B/14 | 84.71 ± 0.00 | 87.75 ± 0.00 | 87.41 ± 0.00 | 87.75 ± 0.00 | 87.41 ± 0.00 | 0.799 ± 0.000 | 0.975 ± 0.000 | 1.99 |
| ConvNeXt-S (IN-22k) [disc] | 75.78 ± 0.00 | 80.12 ± 0.00 | 80.31 ± 0.00 | 80.12 ± 0.00 | 80.06 ± 0.00 | 0.682 ± 0.000 | 0.952 ± 0.000 | 3.26 |
| Best single (val-selected) | 85.73 ± 0.00 | 88.51 ± 0.00 | 87.84 ± 0.00 | 88.51 ± 0.00 | 88.03 ± 0.00 | 0.813 ± 0.000 | 0.976 ± 0.000 | 2.35 |
| Soft vote: top-2 (submitted strategy) | 86.41 ± 0.00 | 89.37 ± 0.00 | 88.68 ± 0.00 | 89.37 ± 0.00 | 88.87 ± 0.00 | 0.822 ± 0.000 | 0.977 ± 0.000 | 2.26 |
| Soft vote: all global | 85.24 ± 0.00 | 88.27 ± 0.00 | 87.92 ± 0.00 | 88.27 ± 0.00 | 87.75 ± 0.00 | 0.806 ± 0.000 | 0.976 ± 0.000 | 2.36 |
| Soft vote: global + disc | 84.65 ± 0.00 | 87.70 ± 0.00 | 87.69 ± 0.00 | 87.70 ± 0.00 | 87.35 ± 0.00 | 0.798 ± 0.000 | 0.976 ± 0.000 | 1.73 |
| Stacking: global only | 86.10 ± 0.00 | 88.83 ± 0.00 | 88.56 ± 0.00 | 88.83 ± 0.00 | 88.54 ± 0.00 | 0.818 ± 0.000 | 0.977 ± 0.000 | 1.81 |
| DA-MVE (proposed) | 86.35 ± 0.00 | 89.24 ± 0.00 | 89.11 ± 0.00 | 89.24 ± 0.00 | 89.03 ± 0.00 | 0.821 ± 0.000 | 0.978 ± 0.000 | 2.13 |

## Statistics (tab_statistics.tex)

| Model | Acc. [95% CI] | Macro-F1 [95% CI] | Macro-AUC [95% CI] | ΔF1 vs proposed [95% CI] | McNemar b/c | p_mcnemar | p_corr_t | p_mcnemar (Holm) |
|---|---|---|---|---|---|---|---|---|
| ResNet50 | 83.62 [82.13, 84.95] | 86.09 [84.66, 87.33] | 0.9733 [0.9698, 0.9766] | +2.95 [+1.91, +3.94] | 149/61 | <0.001 |  | <0.001 |
| MobileNetV4-M | 75.25 [73.47, 76.90] | 75.73 [73.76, 77.54] | 0.9356 [0.9281, 0.9426] | +13.31 [+11.75, +14.96] | 427/69 | <0.001 |  | <0.001 |
| ConvNeXt-T (IN-1k) | 85.73 [84.44, 87.06] | 88.03 [86.85, 89.27] | 0.9757 [0.9713, 0.9795] | +1.01 [+0.14, +1.93] | 82/62 | 0.113 |  | 0.452 |
| ConvNeXt-T (DINOv3) | 82.07 [80.55, 83.46] | 84.49 [83.03, 85.82] | 0.9676 [0.9630, 0.9720] | +4.55 [+3.48, +5.67] | 210/72 | <0.001 |  | <0.001 |
| DINOv2 ViT-B/14 | 84.71 [83.31, 86.09] | 87.41 [86.03, 88.63] | 0.9747 [0.9704, 0.9785] | +1.63 [+0.83, +2.55] | 128/75 | <0.001 |  | 0.001 |
| ConvNeXt-S (IN-22k) [disc] | 75.78 [74.32, 77.37] | 80.06 [78.51, 81.55] | 0.9523 [0.9471, 0.9569] | +8.97 [+7.58, +10.40] | 477/136 | <0.001 |  | <0.001 |
| Best single (val-selected) | 85.73 [84.44, 87.06] | 88.03 [86.85, 89.27] | 0.9757 [0.9713, 0.9795] | +1.01 [+0.14, +1.93] | 82/62 | 0.113 |  | 0.452 |
| Soft vote: top-2 (submitted strategy) | 86.41 [85.11, 87.65] | 88.87 [87.63, 89.99] | 0.9775 [0.9733, 0.9810] | +0.16 [-0.48, +0.86] | 54/56 | 0.924 |  | 0.924 |
| Soft vote: all global | 85.24 [83.88, 86.55] | 87.75 [86.46, 88.97] | 0.9758 [0.9717, 0.9793] | +1.29 [+0.51, +2.08] | 94/58 | 0.004 |  | 0.022 |
| Soft vote: global + disc | 84.65 [83.29, 86.00] | 87.35 [86.04, 88.53] | 0.9762 [0.9723, 0.9795] | +1.68 [+0.92, +2.45] | 104/49 | <0.001 |  | <0.001 |
| Stacking: global only | 86.10 [84.79, 87.35] | 88.54 [87.26, 89.68] | 0.9771 [0.9730, 0.9805] | +0.50 [-0.03, +1.01] | 26/18 | 0.291 |  | 0.582 |
| DA-MVE (proposed) | 86.35 [85.00, 87.59] | 89.03 [87.90, 90.17] | 0.9776 [0.9737, 0.9809] |  |  |  |  |  |

## Per-class performance of the proposed model (tab_per_class.tex)

| Class | Sensitivity (%) | Specificity (%) | F1 (%) | AUC | Support |
|---|---|---|---|---|---|
| AMD | 97.08 | 99.87 | 97.36 | 0.9998 | 171 |
| Cataract | 98.46 | 99.62 | 97.56 | 0.9997 | 325 |
| DR | 78.90 | 96.34 | 84.56 | 0.9573 | 1038 |
| Glaucoma | 84.68 | 97.65 | 85.71 | 0.9790 | 496 |
| Myopia | 87.37 | 98.94 | 85.86 | 0.9810 | 198 |
| Normal | 88.96 | 88.82 | 83.15 | 0.9488 | 996 |

## Normal vs. glaucoma and referable disease (tab_normal_glaucoma.tex)

| Model | Normal→Glaucoma | Glaucoma→Normal | Glaucoma sens. (%) | Referable sens. (%) | Referable spec. (%) | Referable AUC |
|---|---|---|---|---|---|---|
| ResNet50 | 34 | 48 | 81.25 | 86.13 | 90.16 | 0.9373 |
| MobileNetV4-M | 26 | 49 | 76.21 | 82.41 | 85.14 | 0.8955 |
| ConvNeXt-T (IN-1k) | 41 | 44 | 85.48 | 88.78 | 88.25 | 0.9458 |
| ConvNeXt-T (DINOv3) | 32 | 57 | 80.44 | 84.47 | 89.36 | 0.9314 |
| DINOv2 ViT-B/14 | 26 | 58 | 81.45 | 87.57 | 87.65 | 0.9403 |
| ConvNeXt-S (IN-22k) [disc] | 41 | 47 | 81.45 | 83.84 | 76.61 | 0.8960 |
| Best single (val-selected) | 41 | 44 | 85.48 | 88.78 | 88.25 | 0.9458 |
| Soft vote: top-2 (submitted strategy) | 30 | 49 | 83.87 | 88.87 | 88.96 | 0.9479 |
| Soft vote: all global | 26 | 51 | 82.86 | 86.62 | 91.67 | 0.9428 |
| Soft vote: global + disc | 29 | 52 | 82.46 | 86.22 | 91.06 | 0.9433 |
| Stacking: global only | 32 | 45 | 84.07 | 88.69 | 88.96 | 0.9482 |
| DA-MVE (proposed) | 33 | 42 | 84.68 | 88.82 | 88.96 | 0.9488 |

## Referral (tab_referral.tex)

| Model | Acc@100% cov. | Acc@95% cov. | Acc@90% cov. | Acc@80% cov. | AURC (x100) |
|---|---|---|---|---|---|
| DA-MVE (proposed) | 86.35 | 87.85 | 89.35 | 92.44 | 3.82 |
| ConvNeXt-T (IN-1k) | 85.73 | 87.39 | 89.00 | 91.62 | 4.65 |
| Soft vote: top-2 (submitted strategy) | 86.41 | 87.88 | 89.38 | 91.82 | 4.14 |

## Explainability metrics (tab_xai.tex)

| Model | Method | Deletion AUC ↓ | Insertion AUC ↑ | Avg. Drop (%) ↓ | Increase (%) ↑ | Disc enrichment (glaucoma) ↑ | Pointing game (glaucoma, %) ↑ |
|---|---|---|---|---|---|---|---|
| Ensemble of 4 CNNs | Grad-CAM | 0.332 | 0.614 | 16.26 | 30.81 | 4.21 | 72.7 |
| Ensemble of 4 CNNs | Grad-CAM++ | 0.345 | 0.611 | 16.82 | 28.28 | 4.14 | 72.7 |
| Ensemble of 4 CNNs | LayerCAM | 0.348 | 0.601 | 18.68 | 23.74 | 4.10 | 84.8 |
| Ensemble of 4 CNNs | Random | 0.313 | 0.325 | 77.96 | 7.58 | 1.00 | 21.2 |
| ConvNeXt-T (IN-1k) | Grad-CAM | 0.449 | 0.669 | 32.02 | 14.65 | 5.43 | 75.8 |
| ConvNeXt-T (IN-1k) | Grad-CAM++ | 0.447 | 0.680 | 25.34 | 22.73 | 4.91 | 75.8 |
| ConvNeXt-T (IN-1k) | LayerCAM | 0.448 | 0.677 | 26.75 | 23.23 | 4.91 | 78.8 |
| ConvNeXt-T (IN-1k) | Random | 0.308 | 0.305 | 81.50 | 12.63 | 1.00 | 12.1 |

## Model complexity (tab_complexity.tex)

| Model | Input | Params (M) | GFLOPs | Latency (ms) |
|---|---|---|---|---|
| ResNet50 | 256x256 | 23.52 | 10.68 | 6.56 |
| MobileNetV4-M | 256x256 | 8.44 | 2.16 | 9.22 |
| ConvNeXt-T (IN-1k) | 256x256 | 27.82 | 11.64 | 7.62 |
| ConvNeXt-T (DINOv3) | 256x256 | 27.82 | 11.64 | 7.56 |
| DINOv2 ViT-B/14 | 224x224 | 85.73 | 46.32 | 6.73 |
| ConvNeXt-S (IN-22k) [disc] | 192x192 | 49.46 | 12.76 | 13.56 |

## Ensemble members chosen on validation data, per fold

| fold | best_single | top2 |
|---|---|---|
| 0 | ConvNeXt-T (IN-1k) | ConvNeXt-T (IN-1k) + DINOv2 ViT-B/14 |

## Duplicate audit

```json
{
  "n_images": 10029,
  "n_unreadable": 0,
  "classes": [
    "A",
    "C",
    "D",
    "G",
    "M",
    "N"
  ],
  "exact_duplicate_pairs": 164,
  "phash_pairs": 409,
  "deep_pairs": 549,
  "hash_threshold_used_bits_of_256": 25,
  "cosine_threshold_used": 0.97,
  "n_clusters": 9448,
  "n_images_in_clusters_gt1": 1056,
  "largest_cluster": 6,
  "odir_patients": 3098,
  "odir_patients_with_both_eyes": 2336,
  "n_cv_groups": 7114,
  "official_eval_with_dup_in_train": null,
  "naive_70_15_15_test_with_dup_in_train": 0.08637873754152824,
  "naive_70_15_15_test_with_same_patient_in_train": 0.3229235880398671,
  "naive_70_15_15_test_with_dup_or_patient_in_train": 0.4039867109634552,
  "nn_cos_quantiles": {
    "0.5": 0.9356696009635925,
    "0.9": 0.9674786925315857,
    "0.99": 0.9999999403953552
  },
  "label_conflict_clusters": 172,
  "label_conflict_images": 365,
  "label_conflict_classes": {
    "Glaucoma + Myopia": 145,
    "DR + Glaucoma": 8,
    "AMD + DR": 7,
    "DR + Myopia": 6,
    "Cataract + DR": 4,
    "AMD + Glaucoma": 1,
    "Glaucoma + Normal": 1
  },
  "same_odir_eye_in_two_classes": 4,
  "non_fundus_images": 0,
  "excluded_label_conflict": 365,
  "excluded_non_fundus": 0,
  "n_used": 9664,
  "imbalance_ratio_used": 6.166998011928429,
  "chain_probe_acc": 0.5333333333333333,
  "chain_probe_img_size": 256
}
```

## Figures

### fig_benchmark

![fig_benchmark](figures/fig_benchmark.png)

### fig_calibration_referral

![fig_calibration_referral](figures/fig_calibration_referral.png)

### fig_complexity

![fig_complexity](figures/fig_complexity.png)

### fig_confusion

![fig_confusion](figures/fig_confusion.png)

### fig_data_quality

![fig_data_quality](figures/fig_data_quality.png)

### fig_duplicate_audit

![fig_duplicate_audit](figures/fig_duplicate_audit.png)

### fig_gradcam

![fig_gradcam](figures/fig_gradcam.png)

### fig_learning_curves

![fig_learning_curves](figures/fig_learning_curves.png)

### fig_preprocessing

![fig_preprocessing](figures/fig_preprocessing.png)

### fig_roc

![fig_roc](figures/fig_roc.png)

### fig_sources

![fig_sources](figures/fig_sources.png)

### fig_xai_faithfulness

![fig_xai_faithfulness](figures/fig_xai_faithfulness.png)
